const presents = require('./presents.json');

function shuffle(a) {
  var j, x, i;
  for (i = a.length - 1; i > 0; i--) {
      j = Math.floor(Math.random() * (i + 1));
      x = a[i];
      a[i] = a[j];
      a[j] = x;
  }
  return a;
}

// 1. recherche titre
// 2. coup de coeur
// 3. theme
// 4. prix du cadeau
const findpresents = async function findpresents(event) {
  if (event.id) {
    const present = presents.filter((b) => (b.id === event.id));
    if (present.length > 0) return present[0];
  }

  let res = presents;
  if (event.search && event.search.length > 0) {
    res = res.filter((b) => b.title.toLowerCase().indexOf(event.search.toLowerCase()) !== -1);
  }
  if (event.cc) {
    res = res.filter((b) => b.cc.length > 0);
  }
  if (event.theme && event.theme.length > 0 && event.theme !== 'any') {
    res = res.filter((b) => b.theme === event.theme);
  }
  if (event.price && event.price !== 'any') {
    res = res.filter((b) => b.price < event.price);
  }
  return shuffle(res.slice(0, 5));
};
exports.handler = async (event) => findpresents(event);